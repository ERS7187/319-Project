// Search by major name
document.getElementById('searchMajor').addEventListener('keyup', filterMajors);

// Filtering based on selectors
document.getElementById('creditsRequired').addEventListener('change', filterMajors);
document.getElementById('typeOfMajor').addEventListener('change', filterMajors);
document.getElementById('programType').addEventListener('change', filterMajors);

// Function to filter majors
function filterMajors() {
    let searchValue = document.getElementById('searchMajor').value.toLowerCase();
    let credits = document.getElementById('creditsRequired').value;
    let majorType = document.getElementById('typeOfMajor').value;
    let programType = document.getElementById('programType').value;

    document.querySelectorAll('.major-item').forEach(function(item) {
        let textMatch = item.querySelector('.major-title').textContent.toLowerCase().includes(searchValue);
        let creditsMatch = (credits === "" || item.getAttribute('data-credits') === credits);
        let majorTypeMatch = (majorType === "" || item.getAttribute('data-type') === majorType);
        let programTypeMatch = (programType === "" || item.getAttribute('data-program') === programType);
        
        if (textMatch && creditsMatch && majorTypeMatch && programTypeMatch) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// Function to sort the list of majors
function sortList(direction) {
    let list = document.querySelector('.major-list');
    let items = Array.from(list.querySelectorAll('.major-item'));
    items.sort((a, b) => {
        let textA = a.querySelector('.major-title').textContent.toUpperCase();
        let textB = b.querySelector('.major-title').textContent.toUpperCase();
        if (textA < textB) return direction === 'asc' ? -1 : 1;
        if (textA > textB) return direction === 'asc' ? 1 : -1;
        return 0;
    });
    items.forEach(item => list.appendChild(item));
}
